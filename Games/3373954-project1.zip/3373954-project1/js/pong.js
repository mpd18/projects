	/*
	GAME BY Michael Dean
	NID: mi671074
	9/4/17
	class: CAP4720 Richard Leinecker
	*/
	var renderer;
	var scene;
	var camera;
	var spotLight;
	var ball,sphere;
	var BALLSPEED = 0.6;
	var computerPaddle,computerBox;
	var movementLock=1,tickCounter=0;
	var playerPaddle,playerBox;
	var upperBound,lowerBound;
	var playerSide,computerSide;
	//the array for the colors that determine hopw bright each side gets
	var colors = [0x000000,0x191919,0x323232,0x4b4b4b,0x646464,0x7d7d7d,0x969696,0xafafaf,0xc8c8c8,0xe1e1e1,0xffffff];
	var paddleHit,wallHit,score;
	var playerScore=0,computerScore=0,oldPlayerScore=0,oldComputerScore=0;
	var nextColor,colorUp,colorUpBox;
	//the ball sometimes clips through the side of the walls so i implemented a ticker in order to wait a little bit before he next collision is detected
	var intersectTicker=0;
	//the arrays that will hold the box objects that will be added and removed from the scene depending on the score
	var playerScoreSevenSeg = [], computerScoreSevenSeg = [];
	//all of the segment booleans for the 7 segment display
	var segmentCodes = [[1,1,1,1,1,1,0],[0,1,1,0,0,0,0],[1,1,0,1,1,0,1],[1,1,1,1,0,0,1],[0,1,1,0,0,1,1],[1,0,1,1,0,1,1],[1,0,1,1,1,1,1],[1,1,1,0,0,0,0],[1,1,1,1,1,1,1],[1,1,1,1,0,1,1]];
	function init()
	{
		scene = new THREE.Scene();

		camera = new THREE.PerspectiveCamera(
		// frustum vertical view         aspect ratio							 frustum near plane     frustum far plane
			45,                          window.innerWidth / window.innerHeight, 0.1,                   1000 );

		setupRenderer();
		setupCamera();
		addSpotLight();
		
		// Main code here.
		addBall();
		createPlayBottom();
		createBoundingWalls();
		addPaddles();
		addMath();
		loadSounds();
		addColorUps();
		addSevenSegmentScore();
		startBall();

		
		// Output to the stream
		document.body.appendChild( renderer.domElement );
		
		// Call render
		render();
	}
	
	function setupRenderer()
	{
		renderer = new THREE.WebGLRenderer();
		//						color     alpha
		renderer.setClearColor( 0x000000, 1.0 );
		renderer.setSize( window.innerWidth, window.innerHeight );
		renderer.shadowMap.Enabled = true;
	}
	
	function setupCamera()
	{
		camera.position.x = 0;
		camera.position.y = 0;
		camera.position.z = 50;
		camera.lookAt( scene.position );
	}
	
	function addSpotLight()
	{
		spotLight = new THREE.SpotLight( 0xffffff,1);
        spotLight.position.set( 0, 0, 40 );
        spotLight.shadow.camera.near = 20;
        spotLight.shadow.camera.far = 50;
        spotLight.castShadow = true;
        scene.add(spotLight);
	}
	
	function render()
	{
		paddleMover();
		ballMover();
		incrementScore();
		checkBackground();
		colorUpController();
		if(intersectTicker > 0) {
			intersectTicker++;
			if(intersectTicker > 35) {
				intersectTicker = 0;
			}
		}
		// Request animation frame
		requestAnimationFrame( render );
		
		// Call render()
		renderer.render( scene, camera );
	}
	
	function createPlayBottom() {
		var planeGeometry =  new THREE.PlaneGeometry( 35, 39.5, 10, 10   );
		var playerMaterial =  new THREE.MeshLambertMaterial({color:0x000000});
		var computerMaterial = new THREE.MeshLambertMaterial({color: 0x000000});
		playerSide = new THREE.Mesh( planeGeometry, playerMaterial );
		playerSide.position.z = 0;
		playerSide.position.x = 17.5;
		scene.add(playerSide);
		computerSide = new THREE.Mesh(planeGeometry,computerMaterial);
		computerSide.position.z=0;
		computerSide.position.x = -17.5;
		scene.add(computerSide);
		var middleLine =  new THREE.BoxGeometry( .25,70, 0.5 );
		var lineMaterial = new THREE.MeshBasicMaterial({color:'white'});
		var line = new THREE.Mesh( middleLine, lineMaterial );
		line.position.z =  0;
		scene.add(line);
	}
	
	function createBoundingWalls() {
		var leftWall =  new THREE.BoxGeometry( 70,1, 1 );
		var wallMaterial = new THREE.MeshBasicMaterial({color:'white'});
		var wall1 = new THREE.Mesh( leftWall, wallMaterial );
		wall1.position.y =  20;
		scene.add( wall1 );
		var rightWall = new THREE.BoxGeometry( 70, 1, 1  );
		var wall2 = new THREE.Mesh( rightWall, wallMaterial );
		wall2.position.y =  -20;
		scene.add( wall2 );
		upperBound = new THREE.Box3().setFromObject(wall1);
		lowerBound = new THREE.Box3().setFromObject(wall2);
	}
	
	function addPaddles() {
		var topPaddle = new THREE.BoxGeometry(.75,6,1);
		var bottomPaddle = new THREE.BoxGeometry(.75,6,1);
		var paddleMaterial = new THREE.MeshBasicMaterial({color:'white'});
		playerPaddle = new THREE.Mesh(topPaddle,paddleMaterial);
		computerPaddle = new THREE.Mesh(bottomPaddle,paddleMaterial);
		computerPaddle.position.x = -34.25;
		playerPaddle.position.x = 34.25;
		scene.add(playerPaddle);
		scene.add(computerPaddle);
		computerBox = new THREE.Box3().setFromObject(computerPaddle);
		playerBox = new THREE.Box3().setFromObject(playerPaddle);
	}
	
	function addBall() {
		var ballGeometry = new THREE.SphereGeometry(1.25,80,80);
		var ballMaterial = new THREE.MeshBasicMaterial({color: 'white'});
		ball = new THREE.Mesh(ballGeometry,ballMaterial);
		ball.position.x=0;
		ball.position.y=0;
		ball.angle = null;
		ball.direction = null;
		ball.xDirection = 0;
		ball.yDirection = 0;
		sphere = new THREE.Sphere();
		sphere.radius = 1.25;
		scene.add(ball);
	}
	
	function addBoundaries() {
		var normal = new THREE.Vector3(1,0,0);
		var leftPlane = new THREE.Plane(normal,-35);
		scene.add(leftPlane);
		var rightPlane = new THREE.Plane(normal,35);
		scene.add(rightPlane);
		normal = new THREE.Vector3(0,1,0);
		var bottomPlane = new THREE.Plane(normal,19.75)
		var topPlane = new THREE.Plane(normal,-19.75);
		scene.add(bottomPlane);
		scene.add(topPlane);
	}
	
	function paddleMover()
	{
		if( Key.isDown( Key.UPARROW ) && !(playerBox.intersectsBox(upperBound))) {
			playerPaddle.position.y += 0.4;
			playerBox.setFromObject(playerPaddle);
		}
		else if( Key.isDown( Key.DOWNARROW) && !(playerBox.intersectsBox(lowerBound))) {
			playerPaddle.position.y -= 0.4;
			playerBox.setFromObject(playerPaddle);
		}
		if(computerPaddle.position.y < ball.position.y && !(computerBox.intersectsBox(upperBound)) && (ball.direction == 2 || ball.direction == 3)) {
			computerPaddle.position.y += 0.35
			computerBox.setFromObject(computerPaddle);
		}
		else if(computerPaddle.position.y > ball.position.y && !(computerBox.intersectsBox(lowerBound)) && (ball.direction == 2 || ball.direction == 3)) {
			computerPaddle.position.y -= 0.35;
			computerBox.setFromObject(computerPaddle);
		} else if(ball.direction ==1 || ball.direction ==4) {
			if(movementLock==1) {
				direction = Math.floor(Math.random()*2);
				movementLock=0;
			}
			if(computerBox.intersectsBox(upperBound) && direction ==1) {
				direction = 0;
			}
			if(computerBox.intersectsBox(lowerBound) && direction ==0) {
				direction = 1;
			}
			if(direction== 1 && movementLock == 0 && !(computerBox.intersectsBox(upperBound))) {
				computerPaddle.position.y += 0.35;
				computerBox.setFromObject(computerPaddle);
				tickCounter++;
				if(tickCounter >=40) {
					movementLock=1;
					tickCounter=0;
				}
			}
			if(direction == 0 && movementLock == 0 && !(computerBox.intersectsBox(lowerBound))){
				computerPaddle.position.y -=0.35;
				computerBox.setFromObject(computerPaddle);
				tickCounter++;
				if(tickCounter >=40) {
					movementLock=1;
					tickCounter=0;
				}
			}
		}
	}
	
	function addMath() {
		scene.add(sphere);
		scene.add(computerBox);
		scene.add(playerBox);
		scene.add(upperBound);
		scene.add(lowerBound);
	}
	
	function ballMover() {
		if(sphere.intersectsBox(playerBox) || sphere.intersectsBox(computerBox)) {
			redirectBallPaddle();
		}
		if(sphere.intersectsBox(upperBound) || sphere.intersectsBox(lowerBound)) {
			redirectBallBound();
		}
		sphere.center = ball.position;
		//the direction the ball is moving in
		if(ball.direction === 1) {
			ball.position.x += Math.abs(((90-Math.abs(ball.angle))/90)*BALLSPEED);
			ball.position.y += Math.abs((ball.angle/90)*BALLSPEED);
		}
		if(ball.direction === 2) {
			ball.position.x -= Math.abs(((90-Math.abs(ball.angle))/90)*BALLSPEED);
			ball.position.y += Math.abs((ball.angle/90)*BALLSPEED);
		}
		if(ball.direction === 3) {
			ball.position.x -= Math.abs(((90-Math.abs(ball.angle))/90)*BALLSPEED);
			ball.position.y -= Math.abs((ball.angle/90)*BALLSPEED);
		}
		if(ball.direction === 4) {
			ball.position.x += Math.abs(((90-Math.abs(ball.angle))/90)*BALLSPEED);
			ball.position.y -= Math.abs((ball.angle/90)*BALLSPEED);
		}
	}
	
	function startBall() {
		ball.xDirection = Math.floor((Math.random()*160) - 80);
		ball.yDirection = Math.floor((Math.random()*160) - 80);
		if(ball.xDirection < 2.5 && ball.xDirection >=0) {
			ball.xDirection = 2.5;
		}
		if(ball.xDirection > -2.5 && ball.xDirection < 0) {
			ball.xDirection = -2.5;
		}
		if(ball.yDirection < 35 && ball.yDirection >=0) {
			ball.yDirection = 35;
		}
		if(ball.yDirection > -35 && ball.yDirection <0) {
			ball.yDirection = -35;
		}
		if(ball.yDirection > 0 && ball.xDirection > 0) {
			ball.direction = 1;
		}
		if(ball.yDirection > 0 && ball.xDirection < 0) {
			ball.direction = 2;
		}
		if(ball.yDirection < 0 && ball.xDirection < 0) {
			ball.direction = 3;
		}
		if(ball.yDirection < 0 && ball.xDirection > 0) {
			ball.direction = 4;
		}
		ball.angle = Math.floor(Math.atan(ball.yDirection / ball.xDirection) * 180 / Math.PI);
		if(ball.angle > 50) {
			ball.angle = 50;
		}
	}
	
	function redirectBallPaddle() {
		if(intersectTicker === 0) {
			wallHit.play();
			BALLSPEED +=0.1;
			//do the math that redirects the ball based on it's current angle here
			//then new angle is a little random in order to keep the ball from just going through the same pattern over and over
			//makes the game a little more fun
			if(ball.direction === 1) {
				ball.direction = 2;
				//change the angle based on where it hits on the paddle
				ball.angle += Math.floor((Math.random() * 20) - 10);
			}
			else if(ball.direction === 2) {
				ball.direction = 1;
				ball.angle += Math.floor((Math.random() * 20) - 10);
			}
			else if(ball.direction === 3) {
				ball.direction = 4;
				ball.angle += Math.floor((Math.random() * 20) - 10);
			}
			else if(ball.direction === 4) {
				ball.direction = 3;
				ball.angle += Math.floor((Math.random() * 20) - 10);
			}
		}
	}
	//the redirect for the boundaries is different then for the paddles
	//redirects it at a steeper angle sometimes because if it gets to a real steep angle it takes forever and it's not fun
	function redirectBallBound() {
		if(intersectTicker === 0) {
			wallHit.play();
			if(ball.direction === 1) {
				ball.direction = 4;
				if(ball.angle > 45) {
					ball.angle -= 10;
				}
				if(ball.angle < -45) {
					ball.angle += 10;
				}
			}
			else if(ball.direction === 2) {
				ball.direction = 3;
				if(ball.angle > 45) {
					ball.angle -= 10;
				}
				if(ball.angle < -45) {
					ball.angle += 10;
				}
			}
			else if(ball.direction === 3) {
				ball.direction = 2;
				if(ball.angle > 45) {
					ball.angle -= 10;
				}
				if(ball.angle < -45) {
					ball.angle += 10;
				}
			}
			else if(ball.direction === 4) {
				ball.direction = 1;
				if(ball.angle > 45) {
					ball.angle -= 10;
				}
				if(ball.angle < -45) {
					ball.angle += 10;
				}
			}
		}
	}
	
	
	function loadSounds()
	{
		paddleHit = new Audio("sounds/paddleHit.wav");
		wallHit = new Audio("sounds/wallHit.wav");
		score = new Audio("sounds/score.wav");
		background = new Audio("sounds/background.mp3");
		//uncomment when submitting game
		background.play();
		//background.setVolume(15);
	}
	
	function checkBackground() {
		if(!background.isPlaying) {
			background.play();
		}
	}
	
	//adds the color powerup to the scene
	function addColorUps() {
		 nextColor ='0x'+Math.random().toString(16).substr(2,6);
		 var materialColor = '#' + nextColor.substr(2,6);
		 var x = Math.floor((Math.random() * 60) - 30);
		 var y = Math.floor((Math.random()* 30) -15);
		 var colorUpGeometry = new THREE.BoxGeometry(2,2,0.2);
		 var colorUpMaterial = new THREE.MeshLambertMaterial({color: materialColor});
		 colorUp = new THREE.Mesh(colorUpGeometry,colorUpMaterial);
		 colorUp.position.x = x;
		 colorUp.position.y = y;
		 colorUp.position.z=0.3;
		 colorUpBox = new THREE.Box3().setFromObject(colorUp);
		 scene.add(colorUp);
		 scene.add(colorUpBox);
	}
	
	//registers whether the colorUp powerup has been hit by the ball
	function colorUpController() {
		if(colorUpBox.intersectsSphere(sphere)) {
			ball.material.color.setHex(nextColor);
			scene.remove(colorUp);
			scene.remove(colorUpBox);
			addColorUps();
		}
	}
	
	//this controls everything that happens when either player scores
	function incrementScore() {
		
		if(ball.position.x > 35) {
			BALLSPEED = 0.6;
			score.play();
			computerScore++;
			changeScore(computerScore,2);
			if(computerScore >=10) {
				ball.material.color.setHex(0xffffff);
				console.log('You Lose!');
				computerScore = 0;
				playerScore=0;
				//playerSide.material.color.setHex(colors[0]);
			}
			ball.position.set(0,0,0);
			//computerSide.material.color.setHex(colors[computerScore]);
			startBall();
		}
		if(ball.position.x < -35) {
			BALLSPEED = 0.6;
			score.play();
			playerScore++;
			changeScore(playerScore,1);
			if(playerScore >=10) {
				ball.material.color.setHex(0xffffff);
				console.log('You win!');
				playerScore = 0;
				computerScore=0;
				//computerSide.material.color.setHex(colors[0]);
			}
			ball.position.set(0,0,0);
			//playerSide.material.color.setHex(colors[playerScore]);
			startBall();
		}
	}
	
	//this was awful to do I hope you appreciate it
	//it's my way of not doing the awful text geometry that three.js has
	function addSevenSegmentScore() {
		var segmentMaterial = new THREE.MeshBasicMaterial({color: 0x808080});
		
		var verticalGeo = new THREE.BoxGeometry(.5,1.25,.1);
		var middleGeo = new THREE.BoxGeometry(2.05,.5,.1);
		var topGeo = new THREE.BoxGeometry(1,.5,.1);
		var bottomGeo = new THREE.BoxGeometry(1,.5,.1);
		
		var vertSegment = new THREE.Mesh(verticalGeo, segmentMaterial);
		var middleSegment = new THREE.Mesh(middleGeo,segmentMaterial);
		var topSegment = new THREE.Mesh(topGeo,segmentMaterial);
		var bottomSegment = new THREE.Mesh(bottomGeo,segmentMaterial);
		//adding the clones for the player seven segment display
		playerScoreSevenSeg.push(topSegment.clone());
		playerScoreSevenSeg.push(vertSegment.clone());
		playerScoreSevenSeg.push(vertSegment.clone());
		playerScoreSevenSeg.push(bottomSegment.clone());
		playerScoreSevenSeg.push(vertSegment.clone());
		playerScoreSevenSeg.push(vertSegment.clone());
		playerScoreSevenSeg.push(middleSegment.clone());
		//adjusting the positions
		playerScoreSevenSeg[0].position.x = 17.025;
		playerScoreSevenSeg[0].position.y = 18.75;
		playerScoreSevenSeg[0].position.z = 0.5;
		
		playerScoreSevenSeg[1].position.x = 17.775;
		playerScoreSevenSeg[1].position.y = 18.4;
		playerScoreSevenSeg[1].position.z = 0.5;
		
		playerScoreSevenSeg[2].position.x = 17.775;
		playerScoreSevenSeg[2].position.y = 16.6;
		playerScoreSevenSeg[2].position.z = 0.5;
		
		playerScoreSevenSeg[3].position.x = 17;
		playerScoreSevenSeg[3].position.y = 16.25;
		playerScoreSevenSeg[3].position.z = 0.5;
		
		playerScoreSevenSeg[4].position.x = 16.225;
		playerScoreSevenSeg[4].position.y = 16.6;
		playerScoreSevenSeg[4].position.z = 0.5;
		
		playerScoreSevenSeg[5].position.x = 16.225;
		playerScoreSevenSeg[5].position.y = 18.4;
		playerScoreSevenSeg[5].position.z = 0.5;
		
		playerScoreSevenSeg[6].position.x = 17;
		playerScoreSevenSeg[6].position.y = 17.5;
		playerScoreSevenSeg[6].position.z = -0.5;
		//adding the clones for the computer side seven segment display
		computerScoreSevenSeg.push(topSegment.clone());
		computerScoreSevenSeg.push(vertSegment.clone());
		computerScoreSevenSeg.push(vertSegment.clone());
		computerScoreSevenSeg.push(bottomSegment.clone());
		computerScoreSevenSeg.push(vertSegment.clone());
		computerScoreSevenSeg.push(vertSegment.clone());
		computerScoreSevenSeg.push(middleSegment.clone());
		
		//adjusting the positions
		computerScoreSevenSeg[0].position.x = -17.025;
		computerScoreSevenSeg[0].position.y = 18.75;
		computerScoreSevenSeg[0].position.z = 0.5;
		
		computerScoreSevenSeg[5].position.x = -17.775;
		computerScoreSevenSeg[5].position.y = 18.4;
		computerScoreSevenSeg[5].position.z = 0.5;
		
		computerScoreSevenSeg[4].position.x = -17.775;
		computerScoreSevenSeg[4].position.y = 16.6;
		computerScoreSevenSeg[4].position.z = 0.5;
		
		computerScoreSevenSeg[3].position.x = -17;
		computerScoreSevenSeg[3].position.y = 16.25;
		computerScoreSevenSeg[3].position.z = 0.5;
		
		computerScoreSevenSeg[2].position.x = -16.225;
		computerScoreSevenSeg[2].position.y = 16.6;
		computerScoreSevenSeg[2].position.z = 0.5;
		
		computerScoreSevenSeg[1].position.x = -16.225;
		computerScoreSevenSeg[1].position.y = 18.4;
		computerScoreSevenSeg[1].position.z = 0.5;
		
		computerScoreSevenSeg[6].position.x = -17;
		computerScoreSevenSeg[6].position.y = 17.5;
		computerScoreSevenSeg[6].position.z = -0.5;
		
		for(var i=0;i<7;i++) {
			scene.add(computerScoreSevenSeg[i]);
			scene.add(playerScoreSevenSeg[i]);
		}
		
	}
	
	//changes the 7 segment display at the top of each players side
	function changeScore(currentScore,player) {
		if(currentScore < 10) {
			if(player == 1) {
				for(var i=0;i<7;i++) {
					if(segmentCodes[currentScore][i]===1)
					{
						playerScoreSevenSeg[i].position.z = 0.5;
					} else {
						playerScoreSevenSeg[i].position.z = -0.5;
					}
				}
			}
			if(player == 2) {
				for(var i=0;i<7;i++) {
					if(segmentCodes[currentScore][i]===1)
					{
						computerScoreSevenSeg[i].position.z = 0.5;
					} else {
						computerScoreSevenSeg[i].position.z = -0.5;
					}
				}
			}
		} else {
			for(var i=0;i<7;i++) {
					if(segmentCodes[0][i]===1)
					{
						computerScoreSevenSeg[i].position.z = 0.5;
						playerScoreSevenSeg[i].position.z = 0.5;
					} else {
						computerScoreSevenSeg[i].position.z = -0.5;
						playerScoreSevenSeg[i].position.z = -0.5;
					}
				}
		}
		
	}
	window.onload = init;