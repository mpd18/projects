	var renderer;
	var scene;
	var camera;
	var spotLight;
	var smsh;
	var shotBall = false;
	var score;
	var scoreNumber=0;
	var alertUp = false;
	var BALLSPEED = 6000;
	var targets = [];
	var targetPlatformArray = [];
	var targetX = -75;
	var targetCounter = 0;
	var fire,hit;
	var shotCounter = 0;
	var targetAmount = 4;
	
	<!-- add objects in the scope so all methods can access -->
	var groundPlane;
	var ball;

	<!-- 3. Add the following two lines. -->
	Physijs.scripts.worker = 'libs/physijs_worker.js';
    Physijs.scripts.ammo = 'ammo.js';
	
	function init()
	{
		//alert('Space = fire cannonball\nW = aim cannon up\nS = aim cannon down\nH = show help page again');
		
		<!-- 4. Edit the scene creation -->
		scene = new Physijs.Scene();
		scene.setGravity(new THREE.Vector3( 0, 0, -30 ));
		
		setupCamera();
		setupRenderer();
		addSpotLight();
		
		createGroundPlane();
		
		<!-- 7. Create and add cannon -->
		createCannon();
		
		<!-- 11. Create ball -->
		createBall();
		
		<!-- 14. Create target -->
		createTarget();
	
		addScoreText();
		loadSounds();
		// Output to the stream
		document.body.appendChild( renderer.domElement );
		
		// Call render
		render();
	}
	
	function render()
	{
		<!-- 6. Physics simulation -->
		scene.simulate();
		
		<!-- 9. Maintain cannon elevation controls -->
		maintainCannonElevationControls();

		<!-- 12. Look for ball keypresses -->
		maintainBallKeypresses();
		
		<!-- 15. Check for ball off the plane -->
		checkBallPosition();
		
		//change ball speed
		ChangeCannonSpeed();
		//change ball weight
		changeBallWeight();
		
		if(shotBall) {
			cameraFollow();
		} else if (!shotBall){
			resetCamera();
		}
		
		checkIfGameOver();
		// Request animation frame
		requestAnimationFrame( render );
		
		// Call render()
		renderer.render( scene, camera );
	}
	
	<!-- 5. Ground plane -->
	function createGroundPlane()
	{
		var groundTexture = THREE.ImageUtils.loadTexture('textures/ground.jpg');
		var skyTexture = THREE.ImageUtils.loadTexture('textures/sky.jpg');
		
		var planeMaterial = new Physijs.createMaterial(new THREE.MeshLambertMaterial({map:groundTexture}), .4, .8 );
		var skyMaterial = new Physijs.createMaterial(new THREE.MeshLambertMaterial({map:skyTexture}), .4, .8 );
		
		var planeGeometry = new THREE.PlaneGeometry( 500,400, 6 );
		var skyGeometry = new THREE.PlaneGeometry(400,400,6);
		
		skyBackground = new Physijs.BoxMesh( planeGeometry, skyMaterial, 0 );
		skyBackground.rotation.x = Math.PI * .5;
		skyBackground.position.y = 40;
		
		groundPlane = new Physijs.BoxMesh( planeGeometry, planeMaterial, 0 );
		groundPlane.name = "GroundPlane";
		
		scene.add( groundPlane );
		scene.add(skyBackground);
	}
	
	<!-- 7. Create cannon -->
	function createCannon()
	{
		var cylinderGeometry = new THREE.CylinderGeometry( 2, 2, 10 );
		var cylinderMaterial = new THREE.MeshLambertMaterial({color:'lightgray'});
		var can = new THREE.Mesh( cylinderGeometry, cylinderMaterial );
		can.position.y = -5;

		<!-- 8. Create Object3D wrapper that will allow use to correctly rotate -->
		cannon = new THREE.Object3D();
		cannon.add( can );
		
		cannon.rotation.z = Math.PI / 2;
		cannon.position.x -= 150;
		cannon.position.z += 20;
		cannon.name = "CannonBall";
		scene.add( cannon );
		
		var cannonBaseGeo = new THREE.BoxGeometry(15,15,18);
		var cannonBasMat = new THREE.MeshLambertMaterial({color:'grey'});
		var base = new THREE.Mesh(cannonBaseGeo,cannonBasMat);
		base.position.x = cannon.position.x;
		base.position.z = 9;
		scene.add(base);
		
	}
	
	<!-- 9. Maintain cannon elevation controls -->
	function maintainCannonElevationControls()
	{
		if( Key.isDown(Key.W))
		{
			cannon.rotation.y -= 0.01;
			if( cannon.rotation.y < -( Math.PI / 3 ) )
			{
				cannon.rotation.y = -( Math.PI / 3 );
			}
		}
		if( Key.isDown(Key.S))
		{
			cannon.rotation.y += 0.01;
			if( cannon.rotation.y > 0 )
			{
				cannon.rotation.y = 0;
			}
		}
	}
	
	<!-- 12. Look for ball keypresses -->
	var ballLaunched = false;
	function maintainBallKeypresses()
	{
		if( !ballLaunched && Key.isDown(Key.SPACE) && !shotBall)
		{
			createBall();
			ballLaunched = true;
			shotBall = true;
			scene.add( ball );
			fire.play();
			shotCounter++;
			camera.rotation.y = -Math.PI/2;
			camera.rotation.x = Math.PI/2;
			ball.applyCentralImpulse( new THREE.Vector3( BALLSPEED, -( Math.PI / 2 - cannon.rotation.z ) * BALLSPEED, -cannon.rotation.y * BALLSPEED ) );
		}
		if( ballLaunched && !Key.isDown(Key.F) )
		{
			ballLaunched = false
		}
		if(Key.isDown(Key.H) && !ballLaunched && !alertUp) {
			alertUp = true;
			$('#dialog').dialog({
				close: function() {alertUp = false}
			});
		}
	}
	
	<!-- 11. Create ball -->
	var ballNumber = 0;
	function createBall()
	{
		var ballGeometry = new THREE.SphereGeometry( 3,32,32 );
		var ballMaterial = Physijs.createMaterial( new THREE.MeshLambertMaterial({color:'white'}), .95, .95 );
		ball = new Physijs.SphereMesh( ballGeometry, ballMaterial );
		
		ball.position.x = cannon.position.x + Math.cos((Math.PI/2)-cannon.rotation.z) * 10;
		ball.position.y = cannon.position.y - Math.cos(cannon.rotation.z) * 10;
		ball.position.z = cannon.position.z - Math.sin(cannon.rotation.y) * 10;
		
		ball.name = 'shotBall';
		
		ball.addEventListener( 'collision', function( other_object, linear_velocity, angular_velocity )
		{
			if( other_object.name == "GroundPlane" )
			{
				scene.remove(ball);
				shotBall = false;
				resetCamera();
			}
			if(other_object.name.substring(0,6) == 'target') {
				scene.remove(ball);
				shotBall = false;
				resetCamera();
			} else {
				hit.play();
			}
		});
	}

	<!-- 14. Create target -->
	function createTarget()
	{		
		for(var i=0;i<4;i++)
		{
			createTargetFormat(Math.floor(Math.random()*3 +1));
		}
		for(var i = 0;i< targetPlatformArray.length;i++)
		{
			for(var j = 0;j<targetPlatformArray[i].length;j++)
			{
				scene.add(targetPlatformArray[i][j]);
			}
		}
	}
	
	//creates a few different platforms
	function createTargetFormat(number) {		
		var medium = new THREE.BoxGeometry( 4, 4, 12 );
		var small = new THREE.BoxGeometry(4,4,8);
		var large = new THREE.BoxGeometry(4,4,24);
		var mat = Physijs.createMaterial( new THREE.MeshLambertMaterial({color:'green'}), .95, .2 );
		var msh = new Physijs.BoxMesh( medium, mat );
		
		var sg = new THREE.SphereGeometry( 5,32,32 );
		var sm = new Physijs.createMaterial( new THREE.MeshLambertMaterial({color:'red'}), .95, .95 );
		smsh = new Physijs.SphereMesh( sg, sm );
		
		if(number ==1) {
			var target = [];
			for(var i=0;i<4;i++) {
				switch(i) {
					case 0: 
						temp = new Physijs.BoxMesh( medium, mat );
						temp.position.x = targetX - 4.5;
						temp.position.z = 6;
						target.push(temp); 
						break;
					case 1:
						temp = new Physijs.BoxMesh( medium, mat );
						temp.position.x = targetX + 4.5;
						temp.position.z = 6;
						target.push(temp); 
						break;
					case 2:
						temp = new Physijs.BoxMesh( medium, mat );
						temp.position.x = targetX;
						temp.position.z = 6;
						temp.position.y = 3;
						target.push(temp); 
						break;
					case 3:
						temp = new Physijs.BoxMesh( medium, mat );
						temp.position.x = targetX;
						temp.position.z = 6;
						temp.position.y = -3;
						target.push(temp); 
						break;
				}
			}
			var temp = new Physijs.SphereMesh( sg, sm );
			temp.position.x = targetX;
			temp.position.z = 17;
			temp.name = 'target' + targetCounter++;
			target.push(temp);
			targets.push(temp);
			
			targetPlatformArray.push(target);
			targetX += 70;
		}
		if(number == 2) {
			var target = [];
			temp = new Physijs.BoxMesh(large, mat);
			temp.position.x = targetX;
			temp.position.z = 12;
			target.push(temp);
			
			temp = new Physijs.BoxMesh(small,mat);
			temp.position.x = targetX + 8;
			temp.position.z = 4;
			target.push(temp);
			
			temp = new Physijs.SphereMesh(sg,sm);
			temp.position.x = targetX + 8;
			temp.position.z = 13;
			temp.name = 'target' + targetCounter++;
			target.push(temp);
			targets.push(temp);
			
			targetPlatformArray.push(target);
			targetX += 70;
		}
		if(number == 3) {
			var target = [];
			temp = new Physijs.BoxMesh(large, mat);
			temp.position.x = targetX;
			temp.position.z = 12;
			target.push(temp);

			temp = new Physijs.SphereMesh(sg,sm);
			temp.position.x = targetX;
			temp.position.z = 29;
			temp.name = 'target' + targetCounter++;
			target.push(temp);
			targets.push(temp);
			
			targetPlatformArray.push(target);
			targetX +=70;
		}
	}
	
	function ChangeCannonSpeed() {
		if(Key.isDown(Key._1)) {
			BALLSPEED = 6000;
		}
		if(Key.isDown(Key._2)) {
			BALLSPEED = 7000;
		}
		if(Key.isDown(Key._3)) {
			BALLSPEED = 8000;
		}
		if(Key.isDown(Key._4)) {
			BALLSPEED = 9000;
		}
		if(Key.isDown(Key._5)) {
			BALLSPEED = 10000;
		}
		if(Key.isDown(Key._6)) {
			BALLSPEED = 11000;
		}
		if(Key.isDown(Key._7)) {
			BALLSPEED = 12000;
		}
		if(Key.isDown(Key._8)) {
			BALLSPEED = 13000;
		}
		if(Key.isDown(Key._9)) {
			BALLSPEED = 20000;
		}
	}
	
	function changeBallWeight() {
		if(Key.isDown(Key.UPARROW)) {
			ball.material.restitution += 0.1;
		}
		if(Key.isDown(Key.DOWNARROW)) {
			ball.material.restitution -= 0.1;
		}
	}
	
	<!-- 15. Check for ball off the plane -->
	function checkBallPosition()
	{
		for(var i=0;i<4;i++) {
			if(targets[i].position.z < 8 && targets[i].name != 'removed')  {
				console.log('score');
				targets[i].name = 'removed';
				scene.remove(targets[i]);
				scoreNumber++;
				scene.remove(score);
				targetAmount--;
				addScoreText();
			}
		}
		if(ball.position.z < 0 || ball.position.x > 150 || ball.position.z > 200)
		{
			shotBall = false;
			scene.remove(ball);
			resetCamera();
		}
	}
	
	function checkIfGameOver() {
		if(scoreNumber == 4) {
			scoreNumber = 'WINNER!!';
		}
	}
	
	function cameraFollow() {
		camera.position.x = ball.position.x - 80;
		camera.position.y = ball.position.y;
		camera.position.z = ball.position.z + 20;
	}
	
	function resetCamera() {
		camera.position.x = 0;
		camera.position.y = -250;
		camera.position.z = 40;
		camera.lookAt( scene.position );
	}
	
	function setupCamera()
	{
		camera = new THREE.PerspectiveCamera( 45, window.innerWidth / window.innerHeight, 0.1, 1000 );
		camera.position.x = 0;
		camera.position.y = -250;
		camera.position.z = 40;
		camera.lookAt( scene.position );
	}
	
	function setupRenderer()
	{
		renderer = new THREE.WebGLRenderer();
		//						color     alpha
		renderer.setClearColor( 0x000000, 1.0 );
		renderer.setSize( window.innerWidth, window.innerHeight );
		renderer.shadowMap.enabled = true;
	}

	function addSpotLight()
	{
        spotLight = new THREE.SpotLight( 0xffffff );
		spotLight2 = new THREE.SpotLight(0xffffff);
		spotLight3 = new THREE.SpotLight(0xffffff);
        spotLight.position.set( 0, 0, 300 );
        spotLight.shadow.camera.Near = 10;
        spotLight.shadow.camera.far = 100;
        spotLight.castShadow = true;
        scene.add(spotLight);
		
		var targetObject = new THREE.Object3D();
		scene.add(targetObject);
		
		spotLight2.position.set( 0, -200,100 );
        spotLight2.shadow.camera.Near = 10;
        spotLight2.shadow.camera.far = 100;
		scene.add(spotLight2);
		
	}
	
	function addScoreText() {
		var loader = new THREE.FontLoader();
		var scoreGeo;
		loader.load( 'fonts/helvetiker_regular.typeface.json', function ( font ) {

			scoreGeo = new THREE.TextGeometry( typeof(scoreNumber) == 'number' ? 'score: ' + scoreNumber : scoreNumber + ' it took ' + shotCounter + ' shots', {
				font: font,
				size: 20,
				height: 3,
				curveSegments: 20
			} );
			
			var scoreMesh = new THREE.MeshLambertMaterial({color:'red'});
		
			score = new THREE.Mesh(scoreGeo,scoreMesh);
			
			score.position.y = 40;
			score.position.x = cannon.position.x + 100;
			score.position.z = 50;
			score.rotation.x = Math.PI/2;
			if(targetAmount == 0) {
				score.position.x = cannon.position.x + 20;
			}
			scene.add(score);
		} );
		
	}
	
	function loadSounds() {
		fire = new Audio("sounds/Cannon.wav");
		hit = new Audio("sounds/Crash.wav");
	}
	
	
	window.onload = init;
