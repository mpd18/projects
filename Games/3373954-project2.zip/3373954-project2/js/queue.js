var queue = {
	queue : [],
	_currentIndex : 0,
	_lowestIndex : 0,
	enqueue : function(data) {
		queue[_currentIndex] = data;
		_currentIndex++;
	},
	
	dequeue : function() {
		var returnObject = queue[_lowestIndex];
		delete queue[_lowestIndex];
		_lowestIndex++;
		return queue._lowestIndex;
	}
}