	var renderer, rendererHUD,scoreRender;
	var scene;
	var camera, cameraHUD,scoreHUD;
	var gameOver = 0;
	var alertUp = false;
	var player;
	var wallArray = [];
	var pelletArray = [];
	var pacMan;
	var score = 0;
	var pelletName = 0;
	var badGuyName = 0;
	var badGuyArray = [];
	var scoreText;
	var wallMap;
	var holdingGround;
	var gamePlaying = false;
	
	var rw = 200, rh = 150;
	var ca = 100, ar = 2;
	
	var coin,background;
	Physijs.scripts.worker = 'libs/physijs_worker.js';
    Physijs.scripts.ammo = 'ammo.js';
	
	function init()
	{
		$('#dialog').dialog("close");
		scene = new Physijs.Scene();
		scene.setGravity(new THREE.Vector3( 0, 0, -30 ));
		addHoldingGround();
		setupRenderers();
		setupCameras();
		loadSounds();
		background.play();
		
		setupSpotlight(100,100,1);
		setupSpotlight(100,-100,2);
		setupSpotlight(-100,-100,3);
		setupSpotlight(-100,100,4);
		
		setupPlayer();
		
		addGround();
		addEverything();
		addScoreText();
		
		// Main code here.
		
		// Output to the stream
	
		var container = document.getElementById("MainView");
		container.appendChild( renderer.domElement );

		// HUD
		var containerHUD = document.getElementById("HUDView");
		containerHUD.appendChild( rendererHUD.domElement );
		
		var containerScore = document.getElementById("scoreView");
		containerScore.appendChild(scoreRender.domElement);
		
		// Call render
		render();
	}
	
	function checkBackground() {
		if(!background.isPlaying) {
			background.play();
		}
	}
	
	function setupPlayer()
	{
		var ballGeometry = new THREE.SphereGeometry( 1,50,50 );
		var ballMaterial = Physijs.createMaterial( new THREE.MeshLambertMaterial({color:'yellow'}), 1, 0.5 );
		player = new Physijs.SphereMesh( ballGeometry, ballMaterial );		
		
		player.addEventListener( 'collision', function( other_object, relative_velocity, relative_rotation, contact_normal ) {
					
					if(other_object.name.substring(0,6) == "badGuy") {
						loseGame();
					}
		});
		
		player.position.z = 1;
		player.position.y = -10;
		player.position.x = -2;
		player.name = "player";
		
		scene.add( player );
	}
	
	function setupRenderers()
	{
		renderer = new THREE.WebGLRenderer();
		renderer.setClearColor( 0x000000, 0 );
		renderer.setSize( window.innerWidth, window.innerHeight );
		renderer.shadowMap.enabled = true;

		// HUD
		rendererHUD = new THREE.WebGLRenderer();
		rendererHUD.setClearColor( 0x000000, 0 );
		rendererHUD.setSize( rw, rh );
		rendererHUD.shadowMap.enabled = true;
		
		//score
		scoreRender = new THREE.WebGLRenderer();
		scoreRender.setClearColor( 0x000000, 0 );
		scoreRender.setSize( rw, rh );
		scoreRender.shadowMap.enabled = true;
	}
	
	function setupCameras()
	{
		camera = new THREE.PerspectiveCamera(45,window.innerWidth/window.innerHeight,0.1,1000);
		//camera.lookAt( scene.position );
		camera.rotation.x = Math.PI/2;
		camera.position.z = .5;

		// HUD
		cameraHUD = new THREE.PerspectiveCamera(ca,ar,0.1,4000);
		cameraHUD.position.z = 20;
		cameraHUD.lookAt( new THREE.Vector3(0,0,0) );
		
		//score
		scoreHUD = new THREE.PerspectiveCamera(ca,ar,0.1,4000);
		scoreHUD.position.y = 90;
		scoreHUD.position.x = 110;
		scoreHUD.position.z = 50;
		scoreHUD.lookAt(new THREE.Vector3(110,90,0));
	}
	
	function hudFollow() {
		cameraHUD.position.y = player.position.y;
		cameraHUD.position.x = player.position.x;
	}
	
	function render()
	{
		
		// Request animation frame
		requestAnimationFrame( render );
		
		renderer.setViewport( 0, 0, window.innerWidth, window.innerHeight );
		renderer.render( scene, camera );
		
		rendererHUD.setScissorTest(true);
		rendererHUD.setViewport( 0, 0, rw, rh );
		rendererHUD.render( scene, cameraHUD );
		
		scoreRender.setScissorTest(true);
		scoreRender.setViewport( 0, 0, rw, rh );
		scoreRender.render( scene, scoreHUD );
		
		checkBackground();
		
		if(gameOver == 1) {
			return
		}
		scene.simulate();
		//checkPellets();
		movePacman();
		moveBadGuys();
		hudFollow();
		if(Key.isDown(Key.H) && !alertUp) {
			alertUp = true;
			if(!gamePlaying) {
				$('#dialog').dialog({
					close: function() {alertUp = false}
				});
			} else {
				$('#dialog2').dialog({
					close: function() {alertUp = false}
				});
			}
		}
	}
	
	function setBrightness( value )
	{
		var i;
		for( i=1; i<=4; i++ )
		{
			var name = "SpotLight"+i;
			var light = scene.getObjectByName( name );
			light.intensity = value;
		}
	}
	
	function movePacman() {
		var deltaX = camera.getWorldDirection().y *5;
		var deltaZ = camera.getWorldDirection().x *5;
			
		if( Key.isDown( Key.A ) )
		{
			camera.rotation.y += 0.03;
		}
		if( Key.isDown( Key.D ) )
		{
			camera.rotation.y -= 0.03;
		}

		if( Key.isDown( Key.W ))
		{
			player.setLinearVelocity(new THREE.Vector3(deltaZ,deltaX,0));
		}
		
		if(Key.isDown(Key.SPACE) && player.position.z < 2) {
			player.setLinearVelocity(new THREE.Vector3(deltaZ,deltaX,10));
		}
		
		camera.position.x = player.position.x;
		camera.position.y = player.position.y;
		camera.position.z = player.position.z - .5;
	}
	
	function moveBadGuys() {
		for(var i=0;i<badGuyArray.length;i++) {
			badGuyArray[i].setLinearVelocity(new THREE.Vector3((player.position.x-badGuyArray[i].position.x)*.5,(player.position.y-badGuyArray[i].position.y)*.5,0));
		}
	}
	
	function setupSpotlight(x,y,number)
	{
		spotLight = new THREE.SpotLight( 0xffffff);
        spotLight.position.set( x,y, 100 );
		spotLight.target.position.set( x,y,0);
		spotLight.name = "SpotLight"+number;
        scene.add(spotLight);
	}
	
	function loseGame() {
		score = "You Lose";
		scene.remove(scoreText);
		addScoreText();
		gameOver = 1;
		scene.remove(player);
		camera.position.x = 130;
		camera.position.y = 90;
		camera.position.z = 200;
		camera.lookAt(new THREE.Vector3(130,90,0));
	}
	
	function addEverything() {
		var badCounter=0;
		var pelletCounter = 0;
		
		var wallTexture = THREE.ImageUtils.loadTexture('textures/wall.jpg');

		var badGuyTexture = THREE.ImageUtils.loadTexture('textures/badGuy.png');
				
		var start = [-30,14];
		for(var i=0;i<wallMap.length;i++) {
			for(var j=0;j<16;j++) {
				if(wallMap[i][j] == "1") {
					
					var wallBlockGeo = new THREE.BoxGeometry( 4, 4, 4 );
					var mat = new Physijs.createMaterial( new THREE.MeshLambertMaterial({map:wallTexture}), 1, 0 );
					var wallBlock = new Physijs.BoxMesh(wallBlockGeo,mat);
					wallBlock.name = "wallBlock" + (j) + (i);
					wallBlock.position.x = 	start[0];
					wallBlock.position.y = start[1];
					wallBlock.position.z = 2;
					scene.add(wallBlock);
				} else if(wallMap[i][j] == "0") {
					var pelletGeo = new THREE.BoxGeometry(1,1,0.2);
					var pelletMat = new Physijs.createMaterial( new THREE.MeshLambertMaterial({color:"blue"}), 1, .1 );
					var pellet = new Physijs.BoxMesh( pelletGeo, pelletMat );
					pellet.name = "pallet" + (j-1) + (i-1);
					pellet.position.x = start[0];
					pellet.position.y = start[1];
					pellet.position.z = 0.1;
					pellet.addEventListener( 'collision', function( other_object, relative_velocity, relative_rotation, contact_normal ) {
					
					if(other_object.name.substring(0,6) == "player") {
						score +=1;
						coin.play();
						scene.remove(scoreText);
						addScoreText();
						scene.remove(this);

					}
				});	
					pelletArray.push(pellet);
					scene.add(pellet);
				} if(wallMap[i][j] == "x") {
					var ballGeometry = new THREE.SphereGeometry( .5,50,50 );
					var ballMaterial = Physijs.createMaterial( new THREE.MeshLambertMaterial({map:badGuyTexture}), 1, 0.5 );
					var badGuy = new Physijs.SphereMesh( ballGeometry, ballMaterial );
					badGuy.name = "badGuy" + badCounter;
					badGuy.position.x = start[0];
					badGuy.position.y = start[1];
					badGuy.position.z = 0.5;
					badGuyArray.push(badGuy);
					scene.add(badGuy);
					badCounter +=1;
				}
				start[0] +=4;
			}
			start[0] = -30;
			start[1] -=4;
		}
	}
	
	
	function addGround() {
		var groundTexture = THREE.ImageUtils.loadTexture('textures/ground.jpg');
		var groundGeo = new THREE.PlaneGeometry(64,32,0.1);
		var groundMat = new Physijs.createMaterial(new THREE.MeshLambertMaterial({map:groundTexture}), 1,.1);
		groundPlane = new Physijs.BoxMesh(groundGeo,groundMat);
		groundPlane.position.z = 0;
		groundPlane.position.y = 0;
		groundPlane.name = "ground";
		
		scene.add(groundPlane);
	}
	
	function addScoreText() {
		var loader = new THREE.FontLoader();
		var scoreGeo;
		loader.load( 'fonts/helvetiker_regular.typeface.json', function ( font ) {

			scoreGeo = new THREE.TextGeometry( typeof(score)=='number' ? "score: " + score : score, {
				font: font,
				size: 20,
				height: 3,
				curveSegments: 20
			} );
			
			var scoreMesh = new THREE.MeshLambertMaterial({color:'red'});
		
			scoreText = new THREE.Mesh(scoreGeo,scoreMesh);
			
			scoreText.position.y = 90;
			scoreText.position.x = 110;
			scoreText.position.z = 0;
			scene.add(scoreText);
		} );
		
	}
	
	function loadSounds() {
		coin = new Audio("sounds/smb_coin.wav");
		background = new Audio("sounds/background.mp3");
	}
	
	function changeLevel(level) {
		if(level == 1) {
			
			wallMap = ["1111111111111111",
					   "1x001000100000x1",
					   "1010101000101001",
					   "1010001111101011",
					   "1000100010100001",
					   "1010111010101111",
					   "1x100000100000x1",
					   "1111111111111111"];
		} else if(level ==2 ) {
			wallMap = ["1111111111111111",
					   "10001010100000x1",
					   "1011100x00101101",
					   "1010101011101011",
					   "100x101010101001",
					   "1010101010101111",
					   "1x10101010000001",
					   "1111111111111111"];
		} else if(level==3) {
			wallMap = ["1111111111111111",
					   "1000101111111101",
					   "1010001xx1000001",
					   "1111101xx1011111",
					   "1000001xx1000001",
					   "1011111001111101",
					   "1000000000000001",
					   "1111111111111111"];
		}
		gamePlaying = true;
	}
	
	function addHoldingGround() {
		var groundGeo = new THREE.PlaneGeometry(64,32,1);
		var groundMat = new Physijs.createMaterial(new THREE.MeshLambertMaterial({color:"grey"}), 1,.1);
		holdingGround = new Physijs.BoxMesh(groundGeo,groundMat);
		holdingGround.position.z = 0;
		holdingGround.position.y = 0;
		holdingGround.position.x = 100;
		holdingGround.name = "holding";
		
		scene.add(holdingGround);
	}
	
	function checkPellets() {
		for(var i=0;i<pelletArray.length;i++) {
			if(pelletArray[i].position.z < 0) {
				console.log(pelletArray[i].position.z);
				console.log(pelletArray[i].position.x);
				score +=1;
				coin.play();
				pelletArray[i].position.set(100, 0, 5);
				scene.remove(scoreText);
				addScoreText();
				console.log("here " + i);
			}
		}
	}
	
