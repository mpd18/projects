	var renderer;
	var scene;
	var camera;
	var gameOver = 0;
	var alertUp = false;
	var blockMenuUp = false;
	var gamePlaying = false;
	var blockusMap = [];
	var currentBlock = null;
	var rotation = 0;
	var blockChoice = null;
	
	var turn = 0;
	
	var mouse = new THREE.Vector2(), INTERSECTED;
	
	var currentMap = ["00000000000000000000",
					  "00000000000000000000",
					  "00000000000000000000",
					  "00000000000000000000",
					  "00000000000000000000",
					  "00000000000000000000",
					  "00000000000000000000",
					  "00000000000000000000",
					  "00000000000000000000",
					  "00000000000000000000",
					  "00000000000000000000",
					  "00000000000000000000",
					  "00000000000000000000",
					  "00000000000000000000",
					  "00000000000000000000",
					  "00000000000000000000",
					  "00000000000000000000",
					  "00000000000000000000",
					  "00000000000000000000",
					  "00000000000000000000"];
	
	var table;
	var raycaster;
	
	var rw = 200, rh = 150;
	var ca = 100, ar = 2;
	
	Physijs.scripts.worker = 'libs/physijs_worker.js';
    Physijs.scripts.ammo = 'ammo.js';
	
	function setCurrentBlock(choice) {
		console.log(choice);
		blockChoice = choice;
		switch(choice) {
			case 0: currentBlock = [[1,0,0],
									[0,0,0],
									[0,0,0],
									[0,0,0],
									[0,0,0]];
			case 1: currentBlock = [[1,0,0],
									[1,0,0],
									[0,0,0],
									[0,0,0],
									[0,0,0]];
			case 2: currentBlock = [[1,0,0],
									[1,0,0],
									[1,0,0],
									[0,0,0],
									[0,0,0]];
			case 3: currentBlock = [[1,0,0],
									[1,0,0],
									[1,0,0],
									[1,0,0],
									[0,0,0]];
			case 4: currentBlock = [[1,0,0],
									[1,0,0],
									[1,0,0],
									[1,0,0],
									[1,0,0]];
			case 5: currentBlock = [[1,0,0],
									[1,1,1],
									[1,0,0],
									[0,0,0],
									[0,0,0]];
			case 6: currentBlock = [[1,0,0],
									[1,1,0],
									[0,0,0],
									[0,0,0],
									[0,0,0]];
			case 7: currentBlock = [[1,1,1],
									[1,0,1],
									[0,0,0],
									[0,0,0],
									[0,0,0]];
			case 8: currentBlock = [[1,1,1],
									[1,0,0],
									[1,0,0],
									[0,0,0],
									[0,0,0]];
			case 9: currentBlock = [[1,1,0],
									[0,1,0],
									[0,1,1],
									[0,0,0],
									[0,0,0]];
			case 10: currentBlock = [[1,0,0],
									[1,1,0],
									[1,0,0],
									[0,0,0],
									[0,0,0]];
			case 11: currentBlock = [[1,1,0],
									[0,1,0],
									[0,1,0],
									[0,0,0],
									[0,0,0]];
			case 12: currentBlock = [[1,0,0],
									[1,1,1],
									[0,1,0],
									[0,0,0],
									[0,0,0]];
			case 13: currentBlock = [[1,1,0],
									[1,1,0],
									[0,1,0],
									[0,0,0],
									[0,0,0]];
			case 14: currentBlock = [[1,1,0],
									[1,1,0],
									[0,0,0],
									[0,0,0],
									[0,0,0]];
		}
	}
	
	function init()
	{
		raycaster = new THREE.Raycaster();
		scene = new Physijs.Scene();
		scene.setGravity(new THREE.Vector3( 0, 0, -30 ));
		setupCamera();
		setupRenderers();
		loadSounds();
		addTable();
		makeBlockusBoard();
		lightUpSquares();
		
		setupSpotlight(100,100,1);
		setupSpotlight(100,-100,2);
		setupSpotlight(-100,-100,3);
		setupSpotlight(-100,100,4);
		
		 // when the mouse moves, call the given function
		document.addEventListener('mousemove', onDocumentMouseMove, false);
		
		document.addEventListener( 'mousedown', onDocumentMouseDown, false );
		
		
		
		
		// Output to the stream
	
		var container = document.getElementById("MainView");
		container.appendChild( renderer.domElement );
		
		// Call render
		render();
	}
	
	function setupRenderers()
	{
		renderer = new THREE.WebGLRenderer();
		renderer.setClearColor( 0x000000, 0 );
		renderer.setSize( window.innerWidth, window.innerHeight );
		renderer.shadowMap.enabled = true;
	}
	
	function setupCamera()
	{
		camera = new THREE.PerspectiveCamera(45,window.innerWidth/window.innerHeight,0.1,1000);
		camera.position.z = 175;
		camera.position.x = 125;
		camera.lookAt( scene.position );
		camera.rotation.z = Math.PI/2;
	}
	
	function render()
	{
		
		// Request animation frame
		requestAnimationFrame( render );
		
		renderer.setViewport( 0, 0, window.innerWidth, window.innerHeight );
		renderer.render( scene, camera );
		
		//scene.simulate();
		//lightUpSquares()
		//cleanUpColors();
	
		//check for menus
		if(Key.isDown(Key.H) && !alertUp) {
			alertUp = true;
			$('#dialog2').dialog({
				close: function() {alertUp = false}
			});
		}
		
		if(Key.isDown(Key.B) && !alertUp) {
			blockMenuUp = true;
			$('#blockMenu').dialog({
				open: function(event, ui) {
					 // Height setter has no effect after init either
					 $(this).dialog("option", "height", 400 );

					 // Width setter works after initialization too
					 $(this).dialog("option", "width", 600 );
				},
				close: function() {blockMenuUp = false}
			});
		}
		//hoverOver();
	}
	
	
	function setupSpotlight(x,y,number)
	{
		spotLight = new THREE.SpotLight( 0xffffff);
        spotLight.position.set( x,y, 125 );
		spotLight.target.position.set( x,y,0);
		spotLight.name = "SpotLight"+number;
        scene.add(spotLight);
	}
	
	function loadSounds() {
		coin = new Audio("sounds/smb_coin.wav");
		background = new Audio("sounds/background.mp3");
	}
	
	function addTable() {
		var loader = new THREE.OBJLoader();
		
		

		// load a resource
		loader.load(
			// resource URL
			'models/table.obj',
			// Function when resource is loaded
			function ( object ) {
				var tableTexture = THREE.ImageUtils.loadTexture('textures/table.jpg');
				var tableMaterial = new THREE.MeshLambertMaterial({map:tableTexture});
				for(var i = 0; i < object.children.length; i++)
				{
					object.children[i].material = tableMaterial;
				}
				object.position.x = 0;
				object.position.y = 0;
				object.position.z = 0;
				object.rotation.x = Math.PI/2;
				object.material = tableMaterial;
				scene.add( object );
			}
		);
	}
	
	function makeBlockusBoard() {
		var start = [20,-38];
		for(var i = 0; i<20;i++) {
			var blockusRow = [];
			for(var j=0; j<20;j++) {
				nextColor ='0x'+Math.random().toString(16).substr(2,6);
				var materialColor = '#' + nextColor.substr(2,6);
				var blockGeo = new THREE.BoxGeometry(3,3,1);
				var blockMat = new THREE.MeshLambertMaterial({color:0xffffff});
				var block = new THREE.Mesh(blockGeo,blockMat);
				block.position.x = start[0];
				block.position.y = start[1];
				block.position.z = 100;
				//block.rotation.x = Math.PI/2;
				
				block.name = "block" + " " + i + " " + j;
				blockusRow.push(block);
				scene.add(block);
				start[0] += 3.25;
			}
			start[0] = 20;
			start[1] += 3.25;
			blockusMap.push(blockusRow);
		}
	}
	

	function onDocumentMouseMove(event) {
	  // the following line would stop any other event handler from firing
	  // (such as the mouse's TrackballControls)
	  // event.preventDefault();

	  // update the mouse variable
	  mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
	  mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;
	}
	
	function hoverOver() {
		var vector = new THREE.Vector3(mouse.x, mouse.y, 1);
		  vector.unproject(camera);
		  var ray = new THREE.Raycaster(camera.position, vector.sub(camera.position).normalize());

		  // create an array containing all objects in the scene with which the ray intersects
		  var intersects = ray.intersectObjects(scene.children);

		  // INTERSECTED = the object in the scene currently closest to the camera 
		  //		and intersected by the Ray projected from the mouse position 	

		  // if there is one (or more) intersections
		  if (intersects.length > 0) {
			// if the closest object intersected is not the currently stored intersection object
			if (intersects[0].object != INTERSECTED) {
			  // restore previous intersection object (if it exists) to its original color
			  if (INTERSECTED) {
				INTERSECTED.material.color.setHex(INTERSECTED.currentHex);
			  }
			  // store reference to closest object as current intersection object
			  
			  INTERSECTED = intersects[0].object;
			  
			  var array = getRowAndColumn(INTERSECTED.name);
			  var row = Number(array[0]);
			  var column = Number(array[1]);
			  console.log(row + " " +column);
			  
			  // store color of closest object (for later restoration)
			  INTERSECTED.currentHex = INTERSECTED.material.color.getHex();
			  // set a new color for closest object
			  INTERSECTED.material.color.setHex(0xffff00);
			}
		  } else // there are no intersections
		  {
			// restore previous intersection object (if it exists) to its original color
			if (INTERSECTED)
			  INTERSECTED.material.color.setHex(INTERSECTED.currentHex);
			// remove previous intersection object reference
			//     by setting current intersection object to "nothing"
			INTERSECTED = null;
		  }
	}
	
	function onDocumentMouseDown( event ) {
		event.preventDefault();
		mouse.x = ( event.clientX / window.innerWidth ) * 2 - 1;
		mouse.y = - ( event.clientY / window.innerHeight ) * 2 + 1;
		// find intersections
		raycaster.setFromCamera( mouse, camera );
		var intersects = raycaster.intersectObjects( scene.children );
		if ( intersects.length > 0 ) {
		  if ( INTERSECTED != intersects[ 0 ].object ) {
			if ( INTERSECTED ) INTERSECTED.material.emissive.setHex( INTERSECTED.currentHex );
			INTERSECTED = intersects[ 0 ].object;
			var array = getRowAndColumn(INTERSECTED.name);
			var column = Number(array[0]);
			var row = Number(array[1]);
			console.log(row + " " + column);
			
			INTERSECTED.currentHex = INTERSECTED.material.emissive.getHex();
			INTERSECTED.material.emissive.setHex( 0xff00ff );
			 console.log(intersects.length);
		  }
		} else {
		  if ( INTERSECTED ) INTERSECTED.material.emissive.setHex( INTERSECTED.currentHex );
		  INTERSECTED = null;
		}
    }
	
	function placeDownBlock() {
		
	}
	
	function cleanUpColors() {
		for(var i=0;i<19;i++) {
			for(var j =0;j<19;j++) {
				if(currentMap[i][j] != "9" || currentMap[i][j] != "1") {
					blockusMap[i][j].material.color.setHex(0xffffff);
				}
			}
		}
	}
	
	function lightUpSquares() {
		if(turn == 0) {
			blockusMap[0][0].material.color.setHex(0xff00ff);
			blockusMap[0][19].material.color.setHex(0x00ff00);
			blockusMap[19][0].material.color.setHex(0xff0000);
			blockusMap[19][19].material.color.setHex(0x0000ff);
			currentMap[0][0] = "1";
			currentMap[0][19] = "1";
			currentMap[19][0] = "1";
			currentMap[19][19] = "1";
		} else {
			for(var i =0;i<blockusMap.length;i++) {
				for(var j =0;j<blockusMap[i].length;j++) {
					if(blockusMap[i][j].material.color == 0x880088 && i != 0 && j != 0) {
						lightUpTheRest(i,j);
					}
					if(blockusMap[i][j].material.color == 0x00ff00 && i != 0 && j != 19) {
						lightUpTheRest(i,j);
					}
					if(blockusMap[i][j].material.color == 0xff0000 && i != 19 && j != 0) {
						lightUpTheRest(i,j);
					}
					if(blockusMap[i][j].material.color == 0x0000ff && i != 19 && j != 19) {
						lightUpTheRest(i,j);
					}
				}
			}
		}
	}
	
	function lightUpTheRest(row,column) {
		
	}
	
	function whoWon() {
		var green = 0;
		var red = 0;
		var blue = 0;
		var yellow = 0;
		for(var i=0;i<currentMap.length;i++) {
			for(var j=0;j<currentMap.length;j++) {
				switch(currentMap[i][j]) {
					case "2": green +=1;
					break;
					case "3": red += 1;
					break;
					case "4": blue +=1;
					break;
					case "5": yellow +=1;
					break;
					default:
				}
			}
		}
		return Math.max(green,Math.max(red,Math.max(blue,yellow)));
	}
	
	function otherPlayerGo(turn) {
		
		if(turn%4 != 0) {
			if(turn%4 == 1) {
				var piece = pickRandomPiece();
				for(var i =0;i<blockusMap.length;i++) {
					for(var j=0;j<blockusMap.length;j++) {
						if(blockusMap[i][j].emissive = 0xff00ff) {
							var success = AIPlaceDownBlock(i,j);
							if(success) {
								return;
							}
						}
					}
				}
			}
			if(turn%4 == 2) {
				for(var i =0;i<blockusMap.length;i++) {
					for(var j=0;j<blockusMap.length;j++) {
						
					}
				}
			}
			if(turn%4 == 3) {
				for(var i =0;i<blockusMap.length;i++) {
					for(var j=0;j<blockusMap.length;j++) {
						
					}
				}
			}
		}
	}
	
	function pickRandomPiece() {
		var number = Math.floor(Math.random()*15);
		setCurrentBlock(number);
	}
	
	function roateBlock() {
		
	}
	
	function getRowAndColumn(name) {
		array = name.split(" ");
		returnValues = [array[1],array[2]];
		return returnValues;
	}
	
