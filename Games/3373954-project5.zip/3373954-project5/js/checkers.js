	var renderer;
	var scene;
	var camera;
	var gameOver = 0;
	var alertUp = false;
	var blockMenuUp = false;
	var gamePlaying = false;
	var checkerMap = [];
	var currentBlock = null;
	var rotation = 0;
	var blockChoice = null;
	var selectedChecker = null;
	var selectedSquare = null;
	var oldRow = 0;
	var oldColumn = 0;
	var AIArray = [];
	
	var turn = 0;
	
	var mouse = new THREE.Vector2(), INTERSECTED;
	
	var currentMap;
	
	var table;
	var raycaster;
	
	var rw = 200, rh = 150;
	var ca = 100, ar = 2;
	
	Physijs.scripts.worker = 'libs/physijs_worker.js';
    Physijs.scripts.ammo = 'ammo.js';
	
	function init()
	{
		raycaster = new THREE.Raycaster();
		scene = new Physijs.Scene();
		scene.setGravity(new THREE.Vector3( 0, 0, -30 ));
		setupCamera();
		setupRenderers();
		loadSounds();
		addTable();
		makeCheckerBoard();
		makeCheckers();
		//lightUpSquares();
		currentMap = [[0,2,0,0,0,1,0,1],
					  [2,0,2,0,0,0,1,0],
					  [0,2,0,0,0,1,0,1],
					  [2,0,2,0,0,0,1,0],
					  [0,2,0,0,0,1,0,1],
					  [2,0,2,0,0,0,1,0],
					  [0,2,0,0,0,1,0,1],
					  [2,0,2,0,0,0,1,0]];
		
		setupSpotlight(100,100,1);
		setupSpotlight(100,-100,2);
		setupSpotlight(-100,-100,3);
		setupSpotlight(-100,100,4);
		
		 // when the mouse moves, call the given function
		document.addEventListener('mousemove', onDocumentMouseMove, false);
		
		document.addEventListener( 'mousedown', onDocumentMouseDown, false );
		
		
		
		
		// Output to the stream
	
		var container = document.getElementById("MainView");
		container.appendChild( renderer.domElement );
		
		// Call render
		render();
	}
	
	function setupRenderers()
	{
		renderer = new THREE.WebGLRenderer();
		renderer.setClearColor( 0x000000, 0 );
		renderer.setSize( window.innerWidth, window.innerHeight );
		renderer.shadowMap.enabled = true;
	}
	
	function setupCamera()
	{
		camera = new THREE.PerspectiveCamera(45,window.innerWidth/window.innerHeight,0.1,1000);
		camera.position.z = 175;
		camera.position.x = 125;
		camera.lookAt( scene.position );
		camera.rotation.z = Math.PI/2;
	}
	
	function render()
	{
		
		// Request animation frame
		requestAnimationFrame( render );
		
		renderer.setViewport( 0, 0, window.innerWidth, window.innerHeight );
		renderer.render( scene, camera );
		
	
		//check for menus
		if(Key.isDown(Key.H) && !alertUp) {
			alertUp = true;
			$('#dialog2').dialog({
				close: function() {alertUp = false}
			});
		}
		
		if(Key.isDown(Key.B) && !alertUp) {
			blockMenuUp = true;
			$('#blockMenu').dialog({
				open: function(event, ui) {
					 // Height setter has no effect after init either
					 $(this).dialog("option", "height", 400 );

					 // Width setter works after initialization too
					 $(this).dialog("option", "width", 600 );
				},
				close: function() {blockMenuUp = false}
			});
		}
		//hoverOver();
	}
	
	
	function setupSpotlight(x,y,number)
	{
		spotLight = new THREE.SpotLight( 0xffffff);
        spotLight.position.set( x,y, 125 );
		spotLight.target.position.set( x,y,0);
		spotLight.name = "SpotLight"+number;
        scene.add(spotLight);
	}
	
	function loadSounds() {
		coin = new Audio("sounds/smb_coin.wav");
		background = new Audio("sounds/background.mp3");
	}
	
	function addTable() {
		var loader = new THREE.OBJLoader();
		// load a resource
		loader.load(
			// resource URL
			'models/table.obj',
			// Function when resource is loaded
			function ( object ) {
				var tableTexture = THREE.ImageUtils.loadTexture('textures/table.jpg');
				var tableMaterial = new THREE.MeshLambertMaterial({map:tableTexture});
				for(var i = 0; i < object.children.length; i++)
				{
					object.children[i].material = tableMaterial;
				}
				object.position.x = 0;
				object.position.y = 0;
				object.position.z = 0;
				object.rotation.x = Math.PI/2;
				object.material = tableMaterial;
				scene.add( object );
			}
		);
	}
	
	function makeCheckers() {
		var geometry = new THREE.CylinderGeometry( 2.5, 2.5, 1, 32 );
		var myMaterial = new THREE.MeshBasicMaterial( {color: 0xff0000} );
		//var column = 
		for(var i=0;i<4;i++) {
			for(var j = 0;j <3;j++) {
				if(j ==1 ) {
					var bonus = 6;
				} else {
					var bonus = 0;
				}
				var cylinder = new THREE.Mesh( geometry, myMaterial );
				cylinder.position.z = 100.25;
				cylinder.position.x = 25 + (12*i) + bonus;
				cylinder.position.y = 0 + (6*j);
				cylinder.rotation.x = Math.PI/2;
				cylinder.name = "myPiece " + i + " " + j;
				scene.add( cylinder );
			}
		}
		
		var otherMaterial = new THREE.MeshBasicMaterial( {color: 0xdddddd} );
		for(var i=0;i<4;i++) {
			for(var j = 0;j <3;j++) {
				var AIObject = {};
				if(j ==0 || j == 2 ) {
					AIObject.row = (i*2) +1;
					var bonus = 6;
				} else {
					AIObject.row = i*2;
					var bonus = 0;
				}
				AIObject.column = j;
				var cylinder = new THREE.Mesh( geometry, otherMaterial );
				cylinder.position.z = 100.25;
				cylinder.position.x = 25 + (12*i) + bonus;
				cylinder.position.y = -30 + (6*j);
				cylinder.rotation.x = Math.PI/2;
				cylinder.name = "otherPiece " + i + " " + j;
				AIObject.piece = cylinder;
				AIArray.push(AIObject);
				scene.add( cylinder );
			}
		}
	}
	
	function makeCheckerBoard() {
		var start = [25,-30];
		for(var i = 0; i<8;i++) {
			var checkerRow = [];
			for(var j=0; j<8;j++) {
				if((i + j)%2 == 0) {
					color = 0xffffff;
				} else {
					color = 0x000000
				}
				var blockGeo = new THREE.PlaneGeometry(6,6,1);
				var blockMat = new THREE.MeshBasicMaterial({color:color});
				var block = new THREE.Mesh(blockGeo,blockMat);
				block.position.x = start[0];
				block.position.y = start[1];
				block.position.z = 100;
				//block.rotation.x = Math.PI/2;
				
				block.name = "block" + " " + i + " " + j;
				checkerRow.push(block);
				scene.add(block);
				start[0] += 6;
			}
			start[0] = 25;
			start[1] += 6;
			checkerMap.push(checkerRow);
		}
	}
	

	function onDocumentMouseMove(event) {
	  // the following line would stop any other event handler from firing
	  // (such as the mouse's TrackballControls)
	  // event.preventDefault();

	  // update the mouse variable
	  mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
	  mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;
	}
	
	function hoverOver() {
		var vector = new THREE.Vector3(mouse.x, mouse.y, 1);
		  vector.unproject(camera);
		  var ray = new THREE.Raycaster(camera.position, vector.sub(camera.position).normalize());

		  // create an array containing all objects in the scene with which the ray intersects
		  var intersects = ray.intersectObjects(scene.children);

		  // INTERSECTED = the object in the scene currently closest to the camera 
		  //		and intersected by the Ray projected from the mouse position 	

		  // if there is one (or more) intersections
		  if (intersects.length > 0) {
			// if the closest object intersected is not the currently stored intersection object
			if (intersects[0].object != INTERSECTED) {
			  // restore previous intersection object (if it exists) to its original color
			  if (INTERSECTED) {
				INTERSECTED.material.color.setHex(INTERSECTED.currentHex);
			  }
			  // store reference to closest object as current intersection object
			  
			  INTERSECTED = intersects[0].object;
			  
			  var array = getRowAndColumn(INTERSECTED.name);
			  var row = Number(array[0]);
			  var column = Number(array[1]);
			  console.log(row + " " +column);
			  
			  // store color of closest object (for later restoration)
			  INTERSECTED.currentHex = INTERSECTED.material.color.getHex();
			  // set a new color for closest object
			  INTERSECTED.material.color.setHex(0xffff00);
			}
		  } else // there are no intersections
		  {
			// restore previous intersection object (if it exists) to its original color
			if (INTERSECTED)
			  INTERSECTED.material.color.setHex(INTERSECTED.currentHex);
			// remove previous intersection object reference
			//     by setting current intersection object to "nothing"
			INTERSECTED = null;
		  }
	}
	
	function onDocumentMouseDown( event ) {
		event.preventDefault();
		mouse.x = ( event.clientX / window.innerWidth ) * 2 - 1;
		mouse.y = - ( event.clientY / window.innerHeight ) * 2 + 1;
		// find intersections
		raycaster.setFromCamera( mouse, camera );
		var intersects = raycaster.intersectObjects( scene.children );
		if ( intersects.length > 0 ) {
		  if ( INTERSECTED != intersects[ 0 ].object ) {
			INTERSECTED = intersects[ 0 ].object;

			if(intersects.length == 2) {
				unLightSquares();
				if(intersects[0].object.geometry.type == "CylinderGeometry" && intersects[0].object.name.substring(0,7) == "myPiece") {
					var array = getRowAndColumn(intersects[1].object.name);
					var column = Number(array[0]);
					var row = Number(array[1]);
					oldColumn = column;
					oldRow = row;
					
					
					selectedChecker = intersects[0].object;
					selectedSquare = intersects[1].object;
				}
				if(intersects[1].object.geometry.type == "CylinderGeometry" && intersects[1].object.name.substring(0,7) == "myPiece") {
					var array = getRowAndColumn(intersects[0].object.name);
					var column = Number(array[0]);
					var row = Number(array[1]);
					oldColumn = column;
					oldRow = row;
					
					selectedSquare = intersects[0].object;
					selectedChecker = intersects[1].object;
				}
			}
			if(intersects.length == 1) {
				var array = getRowAndColumn(intersects[0].object.name);
				var newColumn = Number(array[0]);
				var newRow = Number(array[1]);
				console.log(newRow + " " + newColumn);
				
				console.log(intersects[0].object.material.color.b);
				
				if(intersects[0].object.material.color.b == 1 && intersects[0].object.material.color.g == 0) {
					console.log(newRow + " " + newColumn);
					currentMap[newRow][newColumn] = 1;
					currentMap[oldRow][oldColumn] = 0;
					console.log(currentMap);
					selectedChecker.position.x = intersects[0].object.position.x;
					selectedChecker.position.y = intersects[0].object.position.y;
					selectedSquare = null;
					selectedChecker = null;
					unLightSquares();
					AITurn();
				}
			}
			if(selectedSquare != null) {
				lightUpOptions(selectedSquare);	
			}
			//console.log(intersects.length);
		  }
		}
    }
	
	function getRowAndColumn(name) {
		array = name.split(" ");
		returnValues = [array[1],array[2]];
		return returnValues;
	}
	
	function unLightSquares() {
		for(var i=0;i<8;i++) {
			for(var j=0;j<8;j++) {
				if(checkerMap[i][j].material.color.b == 1 && checkerMap[i][j].material.color.g == 0) {
					checkerMap[i][j].material.color.setHex(0x000000);
				}
			}
		}
	}
	function AITurn() {
		potentialArray = [];
		positionArray = [];
		for(var i=0;i<AIArray.length;i++) {
			var row = AIArray[i].row;
			var column = AIArray[i].column;
			console.log(row + " " + column)
			if(row > 0 && column < 7&& currentMap[row-1][column + 1] ==0) {
				potentialArray.push(AIArray[i]);
				continue;
			}
			if(row < 7 && column < 7 && currentMap[row+1][column + 1] ==1) {
					potentialArray.push(AIArray[i]);
			}
		}
		var count=0
		while(count < potentialArray.length * 4) {
			var pick = Math.floor(Math.random()*potentialArray.length);
			var row = potentialArray[pick].row;
			var column = potentialArray[pick].column;
			if(row > 1 && column < 6 && currentMap[row-1][column+1] == 1 && currentMap[row-2][column+2] == 0) {
				currentMap[row][column] = 0;
				currentMap[row-2][column+2] = 0;
				potentialArray[pick].row = row-2;
				potentialArray[pick].column = column+2;
				potentialArray[pick].piece.position.x += 12;
				potentialArray[pick].piece.position.y -= 12;
				return;
			}
			if(row < 6 && column < 6 && currentMap[row-1][column+1] == 1 && currentMap[row+2][column+2] == 0) {
				currentMap[row][column] = 0;
				currentMap[row+2][column+2] = 0;
				potentialArray[pick].row = row+2;
				potentialArray[pick].column = column+2;
				potentialArray[pick].piece.position.x -= 12;
				potentialArray[pick].piece.position.y += 12;
				return;
			}
			if(row < 7 && column < 7 && currentMap[row+1][column+1] == 0) {
				currentMap[row][column] = 0;
				currentMap[row+1][column+1] = 2;
				console.log(currentMap);
				potentialArray[pick].row = row-1;
				potentialArray[pick].column = column+1;
				potentialArray[pick].piece.position.x += 6;
				potentialArray[pick].piece.position.y += 6;
				return;
			}
			if(row > 0 && column < 7 && currentMap[row-1][column+1] == 0) {
				currentMap[row][column] = 0;
				currentMap[row-1][column+1] = 2;
				console.log(currentMap);
				potentialArray[pick].row = row+1;
				potentialArray[pick].column = column+1;
				potentialArray[pick].piece.position.x -= 6;
				potentialArray[pick].piece.position.y += 6;
				return;
			}
		}
		
		
	}
	function lightUpOptions(square) {
		array  = getRowAndColumn(square.name);
		var column = Number(array[0]);
		var row = Number(array[1]);
		console.log(row);
		console.log(column);
		console.log(currentMap[row-1]);
		console.log(currentMap[row]);
		console.log(currentMap[row+1]);
		
		if(selectedChecker.name.substring(0,7) == "myPiece") {
			//console.log(currentMap[row-1][column-1]);
			if(column > 0 && row > 0 && currentMap[row -1][column - 1] == 0) {
				checkerMap[column-1][row-1].material.color.setHex(0x0000ff);
			}
			//console.log(currentMap[row+1][column-1]);
			if(row < 7 && column > 0 && currentMap[row+1][column-1] == 0 && row < 7) {
				checkerMap[column-1][row+1].material.color.setHex(0x0000ff);
			}
			if(column > 1 && row > 1 && currentMap[row -1][column - 1] == 2) {
				checkerMap[column-2][row-2].material.color.setHex(0x0000ff);
				
			}
			if(column < 6 && row > 1 && currentMap[row +1][column - 1] == 2) {
				checkerMap[column+2][row-2].material.color.setHex(0x0000ff);
				
			}
			
		}
		
	}
	
