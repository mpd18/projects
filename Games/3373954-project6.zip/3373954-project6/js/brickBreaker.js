	var renderer;
	var scene;
	var camera;
	var gameOver = 0;
	var alertUp = false;
	var blockMenuUp = false;
	var gamePlaying = false;
	var myScore = 0;
	var AIScore = 0;
	var lives = 3;
	var totalPoints =0;
	var AIWait = 0;
	var smash, hit;
	var uniforms1 = {
					time:       { value: 1.0 },
					amplitude : {value : 1.0}
				};
	var clock = new THREE.Clock();
	
	
	var blocker, blockerBound;
	var AIBlocker, AIBlockerBound;
	
	var ball,ballBound,ballVector;
	var AIBall,AIBallBound,AIBallVector;
	
	var groundPlane;
	
	
	var mouse = new THREE.Vector2(), INTERSECTED;
	
	var bricks = [[0,0,0,2,0,0,0],
				  [0,1,1,2,1,1,0],
				  [0,1,1,2,1,1,0],
				  [0,0,2,2,2,0,0],
				  [0,1,1,2,1,1,0],
				  [0,1,1,2,1,1,0],
				  [0,0,0,2,0,0,0]];
				  
	var brickArray = [];
	var boundArray = [];
	
	var sideBoundArray = [];
	
	var shortBoundArray = [];
	var longBoundArray = [];
	
	var raycaster;
	
	var rw = 200, rh = 150;
	var ca = 100, ar = 2;
	
	//Physijs.scripts.worker = 'libs/physijs_worker.js';
    //Physijs.scripts.ammo = 'ammo.js';
	
	function init()
	{
		raycaster = new THREE.Raycaster();
		scene = new THREE.Scene();
		//scene.setGravity(new THREE.Vector3( 0, 0, -30 ));
		getTotalPoints();
		setupCamera();
		setupRenderers();
		initBall();
		AIinitBall();
		loadSounds();
		makeBricks();
		
		setupSpotlight(100,100,1);
		setupSpotlight(100,-100,2);
		setupSpotlight(-100,-100,3);
		setupSpotlight(-100,100,4);
		addPlayingField();
		
		 // when the mouse moves, call the given function
		 document.addEventListener('mousemove', onMouseMove, false);
		
		
		// Output to the stream
	
		var container = document.getElementById("MainView");
		container.appendChild( renderer.domElement );
		
		// Call render
		render();
	}
	
	function setupRenderers()
	{
		renderer = new THREE.WebGLRenderer();
		renderer.setClearColor( 0x000000, 0 );
		renderer.setSize( window.innerWidth, window.innerHeight );
		renderer.shadowMap.enabled = true;
	}
	
	function setupCamera()
	{
		camera = new THREE.PerspectiveCamera(45,window.innerWidth/window.innerHeight,0.1,1000);
		camera.position.z = 100;
		camera.position.y = -10;
		camera.lookAt( scene.position );
		//camera.rotation.z = Math.PI/2;
	}
	
	function render()
	{
		var delta = clock.getDelta();

		uniforms1.time.value += delta * 2;
		uniforms1.amplitude.value +=1;
		// Request animation frame
		requestAnimationFrame( render );
		
		renderer.setViewport( 0, 0, window.innerWidth, window.innerHeight );
		renderer.render( scene, camera );
		
		
		moveBall();
		checkBall();
		AICheckBall();
		checkBrick();
		AIMoveBlocker();
		
		
		//check for menus
		if(Key.isDown(Key.H) && !alertUp) {
			alertUp = true;
			$('#dialog2').dialog({
				close: function() {alertUp = false}
			});
		}
		
		if(Key.isDown(Key.B) && !alertUp) {
			blockMenuUp = true;
			$('#blockMenu').dialog({
				open: function(event, ui) {
					 // Height setter has no effect after init either
					 $(this).dialog("option", "height", 400 );

					 // Width setter works after initialization too
					 $(this).dialog("option", "width", 600 );
				},
				close: function() {blockMenuUp = false}
			});
		}
		//hoverOver();
	}
	
	
	function setupSpotlight(x,y,number)
	{
		spotLight = new THREE.SpotLight( 0xffffff);
        spotLight.position.set( x,y, 20 );
		spotLight.target.position.set( x,y,0);
		spotLight.name = "SpotLight"+number;
        scene.add(spotLight);
	}
	
	function loadSounds() {
		coin = new Audio("sounds/smb_coin.wav");
		background = new Audio("sounds/background.mp3");
	}
	
	function addPlayingField() {
		
		var groundGeo = new THREE.PlaneGeometry(54,80,0.01);
		var groundMat = new Physijs.createMaterial(new THREE.MeshLambertMaterial({color: 0x999999}), 1,.1);
		groundPlane = new Physijs.BoxMesh(groundGeo,groundMat);
		scene.add(groundPlane);
		
		var planeGeo = new THREE.PlaneGeometry(54,80,0.1);
		var mat = new THREE.ShaderMaterial({uniforms : uniforms1, 
											vertexShader : document.getElementById('vertexShader').textContent,
											fragmentShader : document.getElementById('fragment_shader1').textContent});
		var background = new THREE.Mesh(planeGeo,mat);
		scene.add(background);
		
		var wallGeo = new THREE.BoxGeometry(2,80,4);
		var wallMaterial = new THREE.MeshBasicMaterial({color: "red"});
		var wallLeft = new THREE.Mesh(wallGeo,wallMaterial);
		var wallRight = new THREE.Mesh(wallGeo,wallMaterial);
		wallLeft.position.x = -26;
		wallRight.position.x = 26;
		scene.add(wallLeft);
		scene.add(wallRight);
		
		//player Blocker
		var blockerGeo = new THREE.BoxGeometry(6,2,1);
		var blockerMaterial = new THREE.MeshBasicMaterial({color: "green"});
		blocker = new THREE.Mesh(blockerGeo,blockerMaterial);
		blocker.position.y = -38;
		blockerBound = new THREE.Box3();
		blockerBound.setFromObject(blocker);
		scene.add(blocker);
		
		//AI blocker
		var blockerGeo = new THREE.BoxGeometry(6,2,1);
		var blockerMaterial = new THREE.MeshBasicMaterial({color: "black"});
		AIBlocker = new THREE.Mesh(blockerGeo,blockerMaterial);
		AIBlocker.position.y = 38;
		AIBlockerBound = new THREE.Box3();
		AIBlockerBound.setFromObject(AIBlocker);
		scene.add(AIBlocker);
		
		//add background
		var texture = THREE.ImageUtils.loadTexture('textures/BackGround.jpg');
		var backGroundGeo = new THREE.PlaneGeometry(200,200,200);
		var backGroundMaterial = new THREE.MeshLambertMaterial({map:texture});
		var background = new THREE.Mesh(backGroundGeo,backGroundMaterial);
		scene.add(background);
		background.position.z = -10;
	}
	
	function initBall() {
		var ballGeometry = new THREE.SphereGeometry( 1,50,50 );
		var ballMaterial = new THREE.MeshLambertMaterial({color:'yellow'});
		ball = new THREE.Mesh( ballGeometry, ballMaterial );
		ball.position.y = -20;
		scene.add(ball);
		ballBound = new THREE.Sphere();
		ballBound.radius = 1;
		ballVector = new THREE.Vector3(0,1,0);
	}
	
	function AIinitBall() {
		var ballGeometry = new THREE.SphereGeometry( 1,50,50 );
		var ballMaterial = new THREE.MeshLambertMaterial({color:'blue'});
		AIBall = new THREE.Mesh( ballGeometry, ballMaterial );
		AIBall.position.y = 20;
		scene.add(AIBall);
		AIBallBound = new THREE.Sphere();
		AIBallBound.radius = 1;
		AIBallVector = new THREE.Vector3(0,-1,0);
	}
	
	function checkBall() {
		ballBound.center = ball.position;
		if(ball.position.y < -40) {
			if(lives < 1) {
				
			}
			lives -=1;
			ball.position.x = 200;
			ballBound.center = ball.position;
			scene.remove(ball);
			initBall();
		}
		if(ball.position.y >= 40) {
			redirectBall(new THREE.Vector3(0,1,0));
		}
		//if the ball hits the wall redirect it
		if(ball.position.x <-23 || ball.position.x > 23) {
			redirectBall(new THREE.Vector3(1,0,0));
		}
		if(ballBound.intersectsBox(blockerBound)) {
			redirectBall(new THREE.Vector3(0,1,0));
			//positive it hit to the left
			//negative it hit to the right
			var distance = blocker.position.x - ball.position.x;
			if(distance <=0) {
				if(Math.abs(distance) < 1) {
					redirectBall(new THREE.Vector3(-0.894427191,0.447213596,0));
				} else if(Math.abs(distance) < 2) {
					redirectBall(new THREE.Vector3(-0.948683298,0.316227766,0));
				} else {
					redirectBall(new THREE.Vector3(-0.9701425,0.242535625,0));
				}
			}else {
				if(Math.abs(distance) < 1) {
					redirectBall(new THREE.Vector3(0.894427191,0.447213596,0));
				} else if(Math.abs(distance) < 2) {
					redirectBall(new THREE.Vector3(0.948683298,0.316227766,0));
				} else {
					var value = Math.sqrt(5);
					redirectBall(new THREE.Vector3(0.9701425,0.242535625,0));
				}
			}
		}
	}
	
	function AICheckBall() {
		AIBallBound.center = AIBall.position;
		if(AIBall.position.y > 40) {
			if(lives < 1) {
				
			}
			lives -=1;
			AIBall.position.x = 200;
			AIBallBound.center = AIBall.position;
			scene.remove(AIBall);
			AIinitBall();
		}
		if(AIBall.position.y <= -40) {
			AIRedirectBall(new THREE.Vector3(0,1,0));
		}
		//if the ball hits the wall redirect it
		if(AIBall.position.x <-23 || AIBall.position.x > 23) {
			AIRedirectBall(new THREE.Vector3(1,0,0));
		}
		if(AIBallBound.intersectsBox(AIBlockerBound)) {
			//AIRedirectBall(new THREE.Vector3(0,-1,0));
			//positive it hit to the left
			//negative it hit to the right
			var distance = AIBlocker.position.x - AIBall.position.x;
			if(distance <=0) {
				if(Math.abs(distance) < 1) {
					AIRedirectBall(new THREE.Vector3(-0.894427191,-0.447213596,0));
				} else if(Math.abs(distance) < 2) {
					AIRedirectBall(new THREE.Vector3(-0.948683298,-0.316227766,0));
				} else {
					AIRedirectBall( new THREE.Vector3(-0.9701425,-0.242535625,0));
				}
			}else {
				if(Math.abs(distance) < 1) {
					AIRedirectBall(new THREE.Vector3(0.894427191,-0.447213596,0));
				} else if(Math.abs(distance) < 2) {
					AIRedirectBall(new THREE.Vector3(0.948683298,-0.316227766,0));
				} else {
					AIRedirectBall( new THREE.Vector3(0.9701425,-0.242535625,0));
				}
			}
		}
	}
	
	function checkBrick() {
		demoteArray = []
		demoteRow = []
		for(var i=0;i<7;i++) {
			for(var j=0;j<7;j++) {
				if(shortBoundArray[i][j][0].intersectsSphere(ballBound) || shortBoundArray[i][j][1].intersectsSphere(ballBound)) {
					redirectBall(new THREE.Vector3(1,0,0));
					demoteRow[0] = i;
					demoteRow[1] = j;
					demoteArray.push(demoteRow)
					demote(i,j,0);
				}
				if(longBoundArray[i][j][0].intersectsSphere(ballBound) || longBoundArray[i][j][1].intersectsSphere(ballBound)) {
					redirectBall(new THREE.Vector3(0,1,0));
					demoteRow[0] = i;
					demoteRow[1] = j;
					demoteArray.push(demoteRow)
					demote(i,j,0);
				}
				if(shortBoundArray[i][j][0].intersectsSphere(AIBallBound) || shortBoundArray[i][j][1].intersectsSphere(AIBallBound)) {
					AIRedirectBall(new THREE.Vector3(1,0,0));
					demoteRow[0] = i;
					demoteRow[1] = j;
					demoteArray.push(demoteRow)
					demote(i,j,1);
				}
				if(longBoundArray[i][j][0].intersectsSphere(AIBallBound) || longBoundArray[i][j][1].intersectsSphere(AIBallBound)) {
					AIRedirectBall(new THREE.Vector3(0,1,0));
					demoteRow[0] = i;
					demoteRow[1] = j;
					demoteArray.push(demoteRow)
					demote(i,j,1);
				}
			}
		}
	}
	
	function demote(i, j,player) {
		smash.play();
		if(player == 0) {
			myScore +=1;
		} else {
			AIScore +=1;
		}
		if(bricks[i][j] == 2) {
			brickArray[i][j].material.color.setHex(0x0000ff);
			bricks[i][j] -=1;
		} else if(bricks[i][j] == 1 ) {
			brickArray[i][j].material.color.setHex(0xff0000);
			bricks[i][j] -=1;
		} else if(bricks[i][j] == 0 ) {
			bricks[i][j] -= 1;
			moveBrick(i,j);
		}
		if(AIScore + myScore == totalPoints) {
			if(myScore > AIScore ) {
				$( "#gameOver0" ).dialog({
					'height':'300',
					'width':'500',
					open: function(event, ui) {
						 // Height setter has no effect after init either
						 $(this).dialog("option", "height", 400 );

						 // Width setter works after initialization too
						 $(this).dialog("option", "width", 600 );
					 },
					modal: true
					});
			} else if(AIScore > myScore) {
				$( "#gameOver1" ).dialog({
					'height':'300',
					'width':'500',
					open: function(event, ui) {
						 // Height setter has no effect after init either
						 $(this).dialog("option", "height", 400 );

						 // Width setter works after initialization too
						 $(this).dialog("option", "width", 600 );
					 },
					modal: true
					});
			} else {
				$( "#gameOver2" ).dialog({
					'height':'300',
					'width':'500',
					open: function(event, ui) {
						 // Height setter has no effect after init either
						 $(this).dialog("option", "height", 400 );

						 // Width setter works after initialization too
						 $(this).dialog("option", "width", 600 );
					 },
					modal: true
					});
			}
		}
	}
	
	function moveBall(){
		ball.position.x += ballVector.x * .6;
		ball.position.y += ballVector.y * .6;
		
		AIBall.position.x += AIBallVector.x * .6;
		AIBall.position.y += AIBallVector.y * .6;
	}
	
	function redirectBall(normal) {
		hit.play();
		ballVector.reflect(normal);
	}
	function AIRedirectBall(normal) {
		hit.play();
		AIBallVector.reflect(normal);
	}
	
	function makeBricks() {
		
		var brickGeo = new THREE.BoxGeometry(6,2,1);
		var sideboundGeo = new THREE.BoxGeometry(0.1,2,1);
		var longBoundGeo = new THREE.BoxGeometry(6,0.1,1);
		//var brickMaterial1 = new THREE.MeshBasicMaterial({color: 0xff0000});
		//var brickMaterial2 = new THREE.MeshBasicMaterial({color: 0x0000ff});
		//var brickMaterial3 = new THREE.MeshBasicMaterial({color: 0xff00ff});
		
		startx = -21;
		starty = 10;
		for(var i=0;i<7;i++) {
			var row = [];
			var boundRow = [];
			var sideBoundRow = [];
			var longBoundRow = [];
			for(var j=0;j<7;j++) {
				//var brickBound = new THREE.Box3();
				var sideBound1 = new THREE.Box3();
				var sideBound2 = new THREE.Box3();
				var longBound1 = new THREE.Box3();
				var longBound2 = new THREE.Box3();
				if(bricks[i][j] == 0) {
					var brickMaterial1 = new THREE.MeshBasicMaterial({color: 0xff0000});
					var brick = new THREE.Mesh(brickGeo,brickMaterial1);
					var sideBoundMesh1 = new THREE.Mesh(sideboundGeo,brickMaterial1);
					var sideBoundMesh2 = new THREE.Mesh(sideboundGeo,brickMaterial1);
					var longBoundMesh1 = new THREE.Mesh(longBoundGeo,brickMaterial1);
					var longBoundMesh2 = new THREE.Mesh(longBoundGeo,brickMaterial1);
				} else if(bricks[i][j] == 1) {
					var brickMaterial2 = new THREE.MeshBasicMaterial({color: 0x0000ff});
					var brick = new THREE.Mesh(brickGeo,brickMaterial2);
					var sideBoundMesh1 = new THREE.Mesh(sideboundGeo,brickMaterial2);
					var sideBoundMesh2 = new THREE.Mesh(sideboundGeo,brickMaterial2);
					var longBoundMesh1 = new THREE.Mesh(longBoundGeo,brickMaterial2);
					var longBoundMesh2 = new THREE.Mesh(longBoundGeo,brickMaterial2);
				} else if(bricks[i][j] == 2) {
					var brickMaterial3 = new THREE.MeshBasicMaterial({color: 0xff00ff});
					var brick = new THREE.Mesh(brickGeo,brickMaterial3);
					var sideBoundMesh1 = new THREE.Mesh(sideboundGeo,brickMaterial3);
					var sideBoundMesh2 = new THREE.Mesh(sideboundGeo,brickMaterial3);
					var longBoundMesh1 = new THREE.Mesh(longBoundGeo,brickMaterial3);
					var longBoundMesh2 = new THREE.Mesh(longBoundGeo,brickMaterial3);
				} else {
					continue;
				}
				brick.position.x = startx;
				brick.position.y = starty;
				
				sideBoundMesh1.position.x = startx - 3;
				sideBoundMesh1.position.y = starty;
				sideBoundMesh2.position.x = startx + 3;
				sideBoundMesh2.position.y = starty;
				boundRow.push(sideBoundMesh1);
				boundRow.push(sideBoundMesh2);
				
				array1 = [sideBoundMesh1,sideBoundMesh2];
				scene.add(array1[0]);
				scene.add(array1[1]);
				sideBound1.setFromObject(array1[0]);
				sideBound2.setFromObject(array1[1]);
				array3 = [sideBound1,sideBound2];
				
				longBoundMesh1.position.x = startx;
				longBoundMesh1.position.y = starty + 1;
				longBoundMesh2.position.x = startx;
				longBoundMesh2.position.y = starty - 1;
				boundRow.push(longBoundMesh1);
				boundRow.push(longBoundMesh2);
				
				array2 = [longBoundMesh1,longBoundMesh2];
				scene.add(array2[0]);
				scene.add(array2[1]);
				longBound1.setFromObject(array2[0]);
				longBound2.setFromObject(array2[1]);
				array4 = [longBound1,longBound2];
				
				sideBoundRow.push(array3);
				longBoundRow.push(array4);
				row.push(brick);
				scene.add(brick);
				startx +=7;
			}
			boundArray.push(boundRow);
			brickArray.push(row);
			shortBoundArray.push(sideBoundRow);
			longBoundArray.push(longBoundRow);
			startx = -21;
			starty -=3;
		}
	}
	
	function moveBrick(row,column) {
		brickArray[row][column].position.x = 200;

		shortBoundArray[row][column][0].setFromObject(brickArray[row][column]);
		shortBoundArray[row][column][1].setFromObject(brickArray[row][column]);
		longBoundArray[row][column][0].setFromObject(brickArray[row][column]);
		longBoundArray[row][column][1].setFromObject(brickArray[row][column]);
		return true;
	}
	
	function findBrick(brick) {
		for(var i=0;i<7;i++) {
			for(var j=0;j<7;j++) {
				if(brick.uuid == brickArray[i][j].uuid) {
					var array = [];
					array[0] = i;
					array[1] = j;
					return array;
				}
			}
		}
		return null;
	}
	
	function AIMoveBlocker() {
		if(AIBall.position.x > AIBlocker.position.x && (AIBlocker.position.x < 23)) {
			AIBlocker.position.x += 0.5;
		}
		if(AIBall.position.x < AIBlocker.position.x && (AIBlocker.position.x > -23)) {
			AIBlocker.position.x -= 0.5;
		}
		AIBlockerBound.setFromObject(AIBlocker);
	}
	
	function getTotalPoints() {
		for(var i=0;i<7;i++) {
			for(var j=0;j<7;j++) {
				totalPoints += (bricks[i][j] + 1);
			}
		}
	}
	
	function loadSounds() {
		smash = new Audio("sounds/smb_breakblock.wav");
		hit = new Audio("sounds/smb_jumpsmall.wav");
	}
	
	// Follows the mouse event
	function onMouseMove(event) {
		// Update the mouse variable
		event.preventDefault();
		mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
		mouse.y = - (event.clientY / window.innerHeight) * 2 + 1;

	 // Make the sphere follow the mouse
		var vector = new THREE.Vector3(mouse.x, mouse.y, 0.5);
		vector.unproject( camera );
		var dir = vector.sub( camera.position ).normalize();
		var distance = - camera.position.z / dir.z;
		var pos = camera.position.clone().add( dir.multiplyScalar( distance ) );
		if(blocker.position.x > -21 && blocker.position.x < 21) {
			blocker.position.x = pos.x;
			blockerBound.setFromObject(blocker);
		}
		if(blocker.position.x > 20.9) {
			blocker.position.x = 20.9;
			blockerBound.setFromObject(blocker);
		} else if(blocker.position.x < -20.9) {
			blocker.position.x = -20.9;
			blockerBound.setFromObject(blocker);
		}
	};
